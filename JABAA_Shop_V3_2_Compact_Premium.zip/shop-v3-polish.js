/* JABAA Shop V3.1 — accessible product details for mouse, touch and keyboard.
   Read-only DOM enhancement; purchasing remains wired to the original storefront actions. */
(() => {
  'use strict';
  let root, closeButton, lastFocused = null, previousOverflow = '';
  let primaryAction = null;

  function ensureDialog() {
    if (root) return;
    root = document.createElement('div');
    root.className = 'jabaa-details-root';
    root.id = 'jabaa-product-details';
    root.hidden = true;
    root.innerHTML = `
      <div class="jabaa-details-shade" data-details-close="true"></div>
      <section class="jabaa-details-dialog" role="dialog" aria-modal="true" aria-labelledby="jabaa-details-name" tabindex="-1">
        <header class="jabaa-details-topbar"><span>JABAA Shop · Product details</span>
          <button type="button" class="jabaa-details-close" aria-label="Close product details" data-details-close="true">×</button>
        </header>
        <div class="jabaa-details-layout">
          <div class="jabaa-details-art is-book" id="jabaa-details-art"></div>
          <div class="jabaa-details-copy">
            <div class="jabaa-details-meta" id="jabaa-details-meta"></div>
            <h2 class="jabaa-details-title" id="jabaa-details-name"></h2>
            <div class="jabaa-details-subheading">About this product</div>
            <p class="jabaa-details-description" id="jabaa-details-description"></p>
            <ul class="jabaa-details-facts" id="jabaa-details-facts"></ul>
            <div class="jabaa-details-bottom">
              <span class="jabaa-details-price-label">Price</span>
              <div class="jabaa-details-price" id="jabaa-details-price"></div>
              <div class="jabaa-details-actions">
                <button type="button" class="jabaa-details-buy" id="jabaa-details-buy"></button>
                <a class="jabaa-details-preview" id="jabaa-details-preview" target="_blank" rel="noopener noreferrer" hidden>View free preview ↗</a>
              </div>
              <p class="jabaa-details-footer">For local paid products, payment verification continues through the existing JABAA Shop purchase flow.</p>
            </div>
          </div>
        </div>
      </section>`;
    document.body.appendChild(root);
    closeButton = root.querySelector('.jabaa-details-close');
    root.addEventListener('click', (ev) => {
      if (ev.target.closest('[data-details-close]')) close();
    });
    root.querySelector('#jabaa-details-buy').addEventListener('click', () => {
      if (!primaryAction || primaryAction.disabled) return;
      const action = primaryAction;
      close();
      // Preserve the existing, working payment, download and Gumroad behavior.
      action.click();
    });
  }

  function addChip(container, text) {
    const value = String(text || '').trim();
    if (!value) return;
    const chip = document.createElement('span');
    chip.className = 'jabaa-details-chip';
    chip.textContent = value;
    container.append(chip);
  }

  function addFact(container, text) {
    if (!text) return;
    const item = document.createElement('li');
    item.textContent = text;
    container.append(item);
  }

  function openCard(card) {
    if (!card || card.hidden) return;
    ensureDialog();
    if (!root.hidden) close();
    const $ = selector => card.querySelector(selector);
    const isVideo = card.classList.contains('is-video');
    const isEbook = card.classList.contains('is-ebook');
    const type = (card.dataset.kind === 'video') ? 'Video course' : isEbook ? 'PDF / eBook' : 'Digital product';
    const title = $('.product-title')?.textContent?.trim() || 'Digital product';
    const desc = $('.product-desc')?.textContent?.trim() || 'See the full product information and purchase options below.';
    const category = $('.product-category')?.textContent?.trim() || '';
    const meta = $('.product-type')?.textContent?.trim() || '';
    const price = $('.product-price')?.textContent?.trim() || '';

    root.querySelector('#jabaa-details-name').textContent = title;
    root.querySelector('#jabaa-details-description').textContent = desc;
    root.querySelector('#jabaa-details-price').textContent = price;
    const chips = root.querySelector('#jabaa-details-meta');
    chips.replaceChildren();
    addChip(chips, type);
    if (category) addChip(chips, category);
    if (card.dataset.scope === 'international') addChip(chips, 'International · USD');
    else addChip(chips, 'Ethiopia · ETB');
    const facts = root.querySelector('#jabaa-details-facts');
    facts.replaceChildren();
    if (meta && meta !== type) addFact(facts, meta);
    addFact(facts, isVideo ? 'Video learning material' : isEbook ? 'Digital reading material' : 'Digital resource');
    if (card.dataset.free === 'true') addFact(facts, 'Free product');

    const art = root.querySelector('#jabaa-details-art');
    art.className = 'jabaa-details-art ' + (isVideo ? 'is-video' : isEbook ? 'is-book' : 'is-digital');
    art.replaceChildren();
    const sourceImage = $('.product-media img');
    if (sourceImage?.getAttribute('src')) {
      const img = document.createElement('img');
      img.src = sourceImage.src;
      img.alt = title;
      img.loading = 'eager';
      art.appendChild(img);
    } else {
      art.textContent = type;
    }

    primaryAction = $('.product-footer .product-button');
    const buy = root.querySelector('#jabaa-details-buy');
    buy.textContent = primaryAction?.textContent?.trim() || 'Unavailable';
    buy.disabled = !primaryAction || primaryAction.disabled;
    const preview = $('.preview-button');
    const previewAction = root.querySelector('#jabaa-details-preview');
    if (preview?.href && /^https?:/i.test(preview.href)) {
      previewAction.href = preview.href;
      previewAction.hidden = false;
    } else {
      previewAction.hidden = true;
      previewAction.removeAttribute('href');
    }
    lastFocused = document.activeElement;
    previousOverflow = document.body.style.overflow;
    root.hidden = false;
    document.body.style.overflow = 'hidden';
    closeButton.focus({preventScroll:true});
  }
  function close() {
    if (!root || root.hidden) return;
    root.hidden = true;
    document.body.style.overflow = previousOverflow;
    primaryAction = null;
    if (lastFocused?.isConnected && typeof lastFocused.focus === 'function') lastFocused.focus({preventScroll:true});
    lastFocused = null;
  }

  function enhanceCards(grid) {
    if (!grid) return;
    grid.querySelectorAll('.product-card').forEach(card => {
      const media = card.querySelector('.product-media');
      if (!media || media.dataset.jabaaEnhanced) return;
      media.dataset.jabaaEnhanced = 'true';
      media.tabIndex = 0;
      media.setAttribute('role', 'button');
      media.setAttribute('aria-label', 'View details for ' + (card.querySelector('.product-title')?.textContent?.trim() || 'product'));
      if (card.classList.contains('is-ebook')) {
        const wrap = document.createElement('div');
        wrap.className = 'jabaa-book-3d';
        while (media.firstChild) wrap.appendChild(media.firstChild);
        media.appendChild(wrap);
      }
      if (card.classList.contains('is-video')) {
        const play = document.createElement('span');
        play.className = 'jabaa-video-play';
        play.setAttribute('aria-hidden', 'true');
        const tag = document.createElement('span');
        tag.className = 'jabaa-video-tag';
        tag.textContent = 'VIDEO COURSE';
        tag.setAttribute('aria-hidden', 'true');
        media.append(play, tag);
      }
      const details = card.querySelector('.readmore-button');
      if (details) {
        details.hidden = false;
        details.textContent = 'View details ↗';
        details.removeAttribute('aria-expanded');
        details.setAttribute('aria-label', 'View full details for ' + (card.querySelector('.product-title')?.textContent?.trim() || 'product'));
      }
    });
  }

  function start() {
    ensureDialog();
    for (const id of ['books-grid', 'international-products-grid']) {
      const grid = document.getElementById(id);
      if (!grid) continue;
      enhanceCards(grid);
      const observer = new MutationObserver(() => enhanceCards(grid));
      observer.observe(grid, {childList:true});
    }
    document.addEventListener('click', (event) => {
      if (!root.hidden && event.target.closest('#jabaa-product-details')) return;
      const card = event.target.closest('.catalog-section .product-card');
      if (!card) return;
      if (event.target.closest('button, a, input, select, textarea')) return;
      openCard(card);
    });
    document.addEventListener('keydown', (event) => {
      if (!root.hidden) {
        if (event.key === 'Escape') {event.preventDefault();close();return;}
        if (event.key === 'Tab') {
          const focusable = Array.from(root.querySelectorAll('button:not([disabled]), a[href]:not([hidden])')).filter(el => el.offsetParent !== null);
          if (!focusable.length) return;
          const first = focusable[0], last = focusable[focusable.length-1];
          if (event.shiftKey && document.activeElement === first) {event.preventDefault();last.focus();}
          else if (!event.shiftKey && document.activeElement === last) {event.preventDefault();first.focus();}
        }
        return;
      }
      if (!['Enter',' '].includes(event.key)) return;
      const media = event.target.closest('.catalog-section .product-media[role="button"]');
      if (media) {event.preventDefault();openCard(media.closest('.product-card'));}
    });
    window.JabaaProductDetails = {openCard, close};
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start, {once:true});
  else start();
})();
