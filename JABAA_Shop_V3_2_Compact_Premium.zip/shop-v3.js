/* Optional storefront features. If the migration has not been run, the original site still works. */
(() => {
  'use strict';
  const client = window.supabaseClient;
  if (!client) return;
  const el = id => document.getElementById(id);
  function safeActionUrl(input) {
    const value = String(input || '').trim();
    if (/^#[a-z][a-z0-9-]*$/i.test(value)) return value;
    try {
      const u = new URL(value, location.href);
      if (u.protocol === 'https:' || (u.origin === location.origin && u.protocol === 'http:')) return u.href;
    } catch (_) { /* ignore */ }
    return '#local-store';
  }
  function safeImage(input) {
    try {
      const u = new URL(String(input || ''), location.href);
      return ['https:', 'http:'].includes(u.protocol) ? u.href : null;
    } catch (_) { return null; }
  }
  async function loadPromotion() {
    const { data, error } = await client.from('shop_promotions').select('title,subtitle,button_label,button_url,desktop_image_url,mobile_image_url')
      .eq('is_active', true).order('sort_order', { ascending: true }).order('created_at', { ascending: false }).limit(12);
    if (error || !data?.length) return;
    // RLS filters expired and unpublished promotions. The client does not make that decision.
    const p = data[0];
    if (p.title) el('shop-hero-title').textContent = p.title;
    if (p.subtitle) el('shop-hero-subtitle').textContent = p.subtitle;
    if (p.button_label) el('shop-hero-cta').textContent = p.button_label + ' ↗';
    el('shop-hero-cta').href = safeActionUrl(p.button_url);
    const desktop = safeImage(p.desktop_image_url);
    const mobile = safeImage(p.mobile_image_url) || desktop;
    if (desktop) el('shop-hero-image').src = desktop;
    if (mobile) el('shop-hero-mobile-source').srcset = mobile;
  }
  async function trackVisit() {
    if (!window.crypto || typeof window.crypto.randomUUID !== 'function') return;
    let id;
    try {
      id = localStorage.getItem('jabaa_visitor_id');
      if (!id || !/^[0-9a-f-]{36}$/i.test(id)) {
        id = crypto.randomUUID();
        localStorage.setItem('jabaa_visitor_id', id);
      }
    } catch (_) { id = crypto.randomUUID(); }
    try { await client.rpc('shop_track_page_view', { p_visitor_id: id, p_path: '/index.html' }); }
    catch (_) { /* tracking is never required for browsing or purchase */ }
  }
  loadPromotion().catch(() => {});
  trackVisit().catch(() => {});
})();
