(() => {
  'use strict';
  const client = typeof supabaseClient !== 'undefined' ? supabaseClient : window.supabaseClient;
  if (!client || (!window.crypto || typeof window.crypto.randomUUID !== 'function')) return;
  const path=location.pathname.endsWith('dashboard.html')?'/dashboard.html':
             location.pathname.endsWith('course.html')?'/course.html':null;
  if (!path) return;
  let uuid;
  try {
    uuid=localStorage.getItem('jabaa_visitor_id');
    if(!uuid||!/^[0-9a-f-]{36}$/i.test(uuid)) {uuid=crypto.randomUUID();localStorage.setItem('jabaa_visitor_id',uuid);}
  } catch (_) { uuid=crypto.randomUUID(); }
  client.rpc('shop_track_page_view',{p_visitor_id:uuid,p_path:path}).catch(()=>{});
})();
