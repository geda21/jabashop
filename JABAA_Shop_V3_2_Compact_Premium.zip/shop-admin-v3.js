(() => {
  'use strict';
  const client = typeof supabaseClient !== 'undefined' ? supabaseClient : null;
  const $ = id => document.getElementById(id);
  if (!client || !$('shop-promotion-form')) return;
  let promotions = [];
  let permitted = false;
  const status = (id, msg) => { const e=$(id); if(e) e.textContent=msg; };
  function safeImage(url) {
    try { const u = new URL(String(url||''), location.href); return ['http:','https:'].includes(u.protocol) ? u.href : ''; }
    catch (_) { return ''; }
  }
  function safeLink(url) {
    const value=String(url||'').trim();
    if (/^#[a-z0-9-]+$/i.test(value)) return value;
    try { const u=new URL(value, location.href); if(u.protocol==='https:' || u.origin===location.origin) return u.href; }
    catch (_) { }
    return null;
  }
  const val = id => $(id).value.trim();
  function isoOrNull(id) { return val(id) ? new Date(val(id)).toISOString() : null; }
  function toLocalTime(date) {
    if (!date) return '';
    const d=new Date(date), local=new Date(d.getTime()-d.getTimezoneOffset()*60000);
    return local.toISOString().slice(0,16);
  }
  async function requireAdmin() {
    const {data,error}=await client.rpc('shop_is_admin');
    permitted=!error && data===true;
    $('shop-promotion-form').querySelectorAll('input,textarea,button').forEach(i=>i.disabled=!permitted);
    if (!permitted) status('promo-status','Admin features locked. Apply the SQL migration and verify your authorized Supabase Auth account.');
    return permitted;
  }
  async function metrics() {
    status('shop-metrics-status','Loading live database statistics…');
    const {data,error}=await client.rpc('shop_admin_metrics');
    if (error) { status('shop-metrics-status','Unavailable: migration or admin authorization not yet active.'); return; }
    for (const node of document.querySelectorAll('[data-metric]')) {
      const n=data?.[node.dataset.metric];
      node.textContent=(typeof n==='number') ? n.toLocaleString('en-US') : '—';
    }
    status('shop-metrics-status','Live Supabase statistics · approved receipts and recorded page views');
  }
  function reset() {
    $('shop-promotion-form').reset(); $('promo-id').value='';
    $('promo-preview-image').src='assets/jabaa-hero-desktop.webp';
    $('promo-submit').textContent='Save Promotion';
    $('promo-active').checked=true;
    status('promo-status','');
  }
  function render() {
    const root=$('shop-promotion-list');root.replaceChildren();
    if(!promotions.length){root.textContent='No promotions saved yet. The default banner remains visible.';return;}
    promotions.forEach(p=>{
      const entry=document.createElement('div'); entry.className='shop-v3-promo-entry';
      const img=document.createElement('img');img.alt='Promotion artwork';img.src=safeImage(p.desktop_image_url)||'assets/jabaa-hero-desktop.webp';
      const copy=document.createElement('div');
      const name=document.createElement('strong');name.textContent=p.title;
      const state=document.createElement('small');state.textContent=p.is_active?'Published':'Draft';
      const btn=document.createElement('button');btn.type='button';btn.textContent='Edit';btn.addEventListener('click',()=>edit(p));
      copy.append(name,state);entry.append(img,copy,btn);root.append(entry);
    });
  }
  async function list() {
    const {data,error}=await client.from('shop_promotions').select('*').order('created_at',{ascending:false}).limit(30);
    if(error){status('promo-status','Unable to load promotions: '+error.message);return;}
    promotions=data||[];render();
  }
  function edit(p) {
    $('promo-id').value=p.id;
    $('promo-title').value=p.title||'';
    $('promo-subtitle').value=p.subtitle||'';
    $('promo-button').value=p.button_label||'Explore Ebooks';
    $('promo-url').value=p.button_url||'#local-store';
    $('promo-start').value=toLocalTime(p.starts_at);
    $('promo-end').value=toLocalTime(p.ends_at);
    $('promo-active').checked=Boolean(p.is_active);
    $('promo-preview-image').src=safeImage(p.desktop_image_url)||'assets/jabaa-hero-desktop.webp';
    $('promo-submit').textContent='Update Promotion';
    $('shop-promotion-form').scrollIntoView({behavior:'smooth',block:'center'});
  }
  async function upload(file,type) {
    if(!file) return null;
    if(!['image/jpeg','image/png','image/webp'].includes(file.type)) throw Error('Use a JPG, PNG or WebP image.');
    if(file.size>4*1024*1024) throw Error('Each banner must be 4 MB or smaller.');
    const ext=file.type==='image/png'?'png':file.type==='image/webp'?'webp':'jpg';
    const {data,error}=await client.storage.from('shop-assets').upload(`promotions/${crypto.randomUUID()}-${type}.${ext}`,file,{cacheControl:'3600',upsert:false,contentType:file.type});
    if(error) throw error;
    return client.storage.from('shop-assets').getPublicUrl(data.path).data.publicUrl;
  }
  $('promo-desktop-file').addEventListener('change',e=>{
    const f=e.target.files?.[0]; if(f) $('promo-preview-image').src=URL.createObjectURL(f);
  });
  $('promo-cancel').addEventListener('click',reset);
  $('shop-metrics-refresh').addEventListener('click',metrics);
  $('shop-promotion-form').addEventListener('submit',async e=>{
    e.preventDefault(); if(!permitted)return;
    const link=safeLink(val('promo-url'));
    if(!link){status('promo-status','Use an internal #section link or a secure https:// URL.');return;}
    const start=isoOrNull('promo-start'), end=isoOrNull('promo-end');
    if(start && end && start>=end){status('promo-status','End date must be later than the start date.');return;}
    const id=val('promo-id'), current=promotions.find(x=>x.id===id);
    $('promo-submit').disabled=true;status('promo-status','Saving artwork and promotion…');
    try{
      const [desktop,mobile]=await Promise.all([
        upload($('promo-desktop-file').files?.[0],'desktop'),upload($('promo-mobile-file').files?.[0],'mobile')
      ]);
      const payload={title:val('promo-title'),subtitle:val('promo-subtitle'),button_label:val('promo-button'),button_url:link,
        desktop_image_url:desktop||current?.desktop_image_url||null,
        mobile_image_url:mobile||current?.mobile_image_url||null,
        starts_at:start,ends_at:end,is_active:$('promo-active').checked,sort_order:current?.sort_order||0};
      const result=id?await client.from('shop_promotions').update(payload).eq('id',id):await client.from('shop_promotions').insert(payload);
      if(result.error)throw result.error;
      reset();await list();status('promo-status','Promotion saved. Refresh the storefront to preview it.');
    }catch(err){status('promo-status','Could not save: '+(err.message||String(err)));}
    finally{$('promo-submit').disabled=false;}
  });
  (async()=>{const {data:{user}}=await client.auth.getUser();if(!user)return;if(await requireAdmin()){await Promise.all([metrics(),list()]);}})().catch(err=>status('promo-status',err.message));
})();
